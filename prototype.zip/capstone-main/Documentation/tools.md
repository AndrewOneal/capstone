# ASE 485 Capstone Tools
* We will use Dart/Flutter for our language and framework.
* We will use GitHub for version control.
* We will use our IDE's of personal choice.
* We will use LoC tool to update our LoC's weekly.
* We will use Canvas for our scheduling.
