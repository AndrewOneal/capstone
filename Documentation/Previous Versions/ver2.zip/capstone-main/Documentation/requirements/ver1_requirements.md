Iteration 1 Requirements

* Front End
  * Epic: Complete Front-End Architecture
  * Epic: Complete Front-End Design
* Back End
  * Epic: Complete Back-End Architecture
  * Epic: Complete Back-End Design
