# ASE 485 Capstone Rules
* The team will communicate via Discord.
* Everyone must respond to tagged messages within 48 Hours. (-5 points)
* Communicate when there are issues or needs, no surprises especially close to due dates. (-5 points)
* Attend team meetings. (-5 points)
* Update progress weekly both verbally and through LoC/pull requests. (-5 points)
* Meet deadlines. (-5 points)
