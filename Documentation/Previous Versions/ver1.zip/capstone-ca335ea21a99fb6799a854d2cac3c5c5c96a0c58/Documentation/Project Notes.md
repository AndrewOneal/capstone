Logging is being done with devlogger tool built into dart

Characters/Seasons page should just have the data passed to them through route arguements. I should minimize API calls where possible

need plan for how to properly do error handling when pulling descriptions and names

Need plan for EXACTLY what information will be on each page

Need to CONSTANTLY be testing both android and web platforms to make sure they're both working properly

Database Design:
USERS [TABLE]:

