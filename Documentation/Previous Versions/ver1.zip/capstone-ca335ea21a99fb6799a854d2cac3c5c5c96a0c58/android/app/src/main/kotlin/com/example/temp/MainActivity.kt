package com.example.temp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
